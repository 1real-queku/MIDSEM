package converter;

public class CurrencyConverter {
    public double dollarToGhc(double dollar) { return dollar * 13.5; }
    public double euroToGhc(double euro) { return euro * 14.7; }
    public double yenToGhc(double yen) { return yen * 0.1; }
    public double ghcToDollar(double ghc) { return ghc / 13.5; }
    public double ghcToEuro(double ghc) { return ghc / 14.7; }
    public double ghcToYen(double ghc) { return ghc / 0.1; }
}
