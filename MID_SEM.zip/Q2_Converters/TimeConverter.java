package converter;

public class TimeConverter {
    public int hoursToMinutes(int hours) { return hours * 60; }
    public int minutesToHours(int minutes) { return minutes / 60; }
    public int minutesToSeconds(int minutes) { return minutes * 60; }
    public int secondsToMinutes(int seconds) { return seconds / 60; }
}
