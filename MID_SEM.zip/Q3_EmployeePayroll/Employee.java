class Employee {
    String empName, empId, address, mailId;
    String mobileNo;

    public Employee(String name, String id, String address, String mailId, String mobile) {
        this.empName = name;
        this.empId = id;
        this.address = address;
        this.mailId = mailId;
        this.mobileNo = mobile;
    }

    public void display() {
        System.out.println("Name: " + empName);
        System.out.println("ID: " + empId);
        System.out.println("Address: " + address);
        System.out.println("Mail ID: " + mailId);
        System.out.println("Mobile No: " + mobileNo);
    }
}
