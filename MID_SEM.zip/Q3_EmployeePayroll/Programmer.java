class Programmer extends Employee {
    double basicPay;

    public Programmer(String name, String id, String address, String mailId, String mobile, double bp) {
        super(name, id, address, mailId, mobile);
        this.basicPay = bp;
    }

    public void generatePaySlip() {
        double da = 0.97 * basicPay;
        double hra = 0.1 * basicPay;
        double pf = 0.12 * basicPay;
        double staffClub = 0.001 * basicPay;
        double gross = basicPay + da + hra;
        double net = gross - pf - staffClub;

        display();
        System.out.println("Gross Salary: " + gross);
        System.out.println("Net Salary: " + net);
    }
}
