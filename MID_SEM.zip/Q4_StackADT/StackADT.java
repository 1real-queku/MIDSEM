interface StackADT {
    void push(int item) throws Exception;
    int pop() throws Exception;
    int peek() throws Exception;
    boolean isEmpty();
    boolean isFull();
}
