class ArrayStack implements StackADT {
    private int maxSize;
    private int[] stackArray;
    private int top;

    public ArrayStack(int size) {
        maxSize = size;
        stackArray = new int[maxSize];
        top = -1;
    }

    public void push(int item) throws Exception {
        if (isFull()) throw new Exception("Stack Overflow");
        stackArray[++top] = item;
    }

    public int pop() throws Exception {
        if (isEmpty()) throw new Exception("Stack Underflow");
        return stackArray[top--];
    }

    public int peek() throws Exception {
        if (isEmpty()) throw new Exception("Stack is empty");
        return stackArray[top];
    }

    public boolean isEmpty() { return (top == -1); }

    public boolean isFull() { return (top == maxSize - 1); }
}
