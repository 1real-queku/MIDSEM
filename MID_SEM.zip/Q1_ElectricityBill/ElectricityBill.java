class ElectricityBill {
    int consumerNo;
    String consumerName;
    int prevReading, currReading;
    String ebConnectionType;

    public ElectricityBill(int consumerNo, String consumerName, int prevReading, int currReading, String ebConnectionType) {
        this.consumerNo = consumerNo;
        this.consumerName = consumerName;
        this.prevReading = prevReading;
        this.currReading = currReading;
        this.ebConnectionType = ebConnectionType.toLowerCase();
    }

    public double calculateBill() {
        int units = currReading - prevReading;
        double amount = 0;

        if (ebConnectionType.equals("domestic")) {
            if (units <= 100) amount = units * 1;
            else if (units <= 200) amount = 100 * 1 + (units - 100) * 2.5;
            else if (units <= 500) amount = 100 * 1 + 100 * 2.5 + (units - 200) * 4;
            else amount = 100 * 1 + 100 * 2.5 + 300 * 4 + (units - 500) * 6;
        } else if (ebConnectionType.equals("commercial")) {
            if (units <= 100) amount = units * 2;
            else if (units <= 200) amount = 100 * 2 + (units - 100) * 4.5;
            else if (units <= 500) amount = 100 * 2 + 100 * 4.5 + (units - 200) * 6;
            else amount = 100 * 2 + 100 * 4.5 + 300 * 6 + (units - 500) * 7;
        }

        return amount;
    }

    public void displayBill() {
        System.out.println("Consumer No: " + consumerNo);
        System.out.println("Consumer Name: " + consumerName);
        System.out.println("Units Consumed: " + (currReading - prevReading));
        System.out.println("Connection Type: " + ebConnectionType);
        System.out.println("Amount to Pay: Gh. " + calculateBill());
    }
}
